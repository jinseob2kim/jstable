library(testthat)
library(jstable)

test_check("jstable")
